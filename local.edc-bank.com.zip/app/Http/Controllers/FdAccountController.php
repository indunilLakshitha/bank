<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FdAccountController extends Controller
{
    //
}
