<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InteresetSchema extends Model
{
    protected $fillable = [
        'sub_account_id',
        'interest_type_id',
        'bonus_date',
        'interest_frequently_id',
        'interest_credit_dated',
        'is_enable',
        'created_by',
        'updated_by',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
    ];
}
