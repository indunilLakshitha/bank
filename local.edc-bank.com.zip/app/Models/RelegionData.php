<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RelegionData extends Model
{
    //
}
