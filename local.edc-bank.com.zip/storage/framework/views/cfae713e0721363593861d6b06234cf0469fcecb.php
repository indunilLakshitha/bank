<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="col-md-10 col-12 mr-auto ml-auto">
            <div class="card">
                <div class="card-body">
                    <form id="private_1" action="/member/add/benificiaris" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="customer_id" value=<?php echo e($cus_id); ?>>
                        <div class="tab-pane active" id="private_1">
                            
                            <h5 class="">Beneficiaries</h5>
                            <div class="row">
                                <label class="col-sm-1 col-form-label">Add</label>
                                <div class="col-sm-2">
                                    <select name=""  class="form-control" id="select_bene">
                                        <?php $__currentLoopData = $all_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->customer_id); ?>"><?php echo e($customer->name_in_use); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> </div>
                                <div class="col-sm-2">
                                    <a class="btn btn-sm btn-primary"
                                    onclick="add_bene_guard('/bene', '<?php echo e($cus_id); ?>', select_bene.value)"
                                    >ADD</a>
                                </div>
                                
                            </div>
                            <div class="row">
                                <table class="table text-center d-none" id="bene_table">
                                   <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Beneficiary Name</th>
                                    </tr>
                                   </thead>
                                   <tbody id="bene_body">

                                   </tbody>
                                </table>
                            </div>

                            <br>
                            <h5 class="">Guardians</h5>
                            <div class="row">
                                <label class="col-sm-1 col-form-label">1st</label>
                                <div class="col-sm-2">
                                    <select name="" id="select_guard" class="form-control" >
                                        <?php $__currentLoopData = $all_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->customer_id); ?>"><?php echo e($customer->name_in_use); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> </div>
                                <div class="col-sm-2">
                                    <a class="btn btn-sm btn-primary"
                                    onclick="add_bene_guard('/guard', '<?php echo e($cus_id); ?>', select_guard.value)"
                                    >ADD</a>
                                </div>
                                
                            </div>
                            <div class="row">
                                <table class="table text-center d-none" id="guard_table">
                                   <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Guardian Name</th>
                                    </tr>
                                   </thead>
                                   <tbody id="guard_body">

                                   </tbody>
                                </table>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">NEXT</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    function add_bene_guard(url, customer_id, id){

        $.ajax({
            type : 'GET',
            url,
            data : {
                customer_id, id
            },
            success : function(data) {
                if(data[0] === 'bene'){
                    bene_table.classList.remove('d-none')
                    bene_body.innerHTML = ''

                    let i = 1
                    data[1].forEach(r => {
                        html = `
                        <tr>
                            <th> ${i} </th>
                            <th> ${r.name_in_use} </th>
                        </tr>
                        `
                        i++
                        bene_body.innerHTML += html
                    })

                } else if (data[0] === 'guard'){
                    guard_table.classList.remove('d-none')
                    guard_body.innerHTML = ''

                    let i = 1
                    data[1].forEach(r => {
                        html = `
                        <tr>
                            <th> ${i} </th>
                            <th> ${r.name_in_use} </th>
                        </tr>
                        `
                        i++
                        guard_body.innerHTML += html
                    })
                }

            }
        })
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/members/5_benificiaries.blade.php ENDPATH**/ ?>