<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                
                <h4 class="card-title">Permissions
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_users')): ?>
                    <a href="/users/add" rel="tooltip" class="btn btn-sm btn-primary btn-round pull-right">
                        <i class="material-icons">add</i> <span class="mx-1">Add User</span>
                    </a>
                    <?php endif; ?>
                </h4>

            </div>
            <div class="card-body ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="material-datatables">
                            <table id="datatables" class="table table-striped table-no-bordered table-hover"
                                cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <th>Full Name </th>
                                    <th>Email</th>
                                    <th>Branch</th>
                                    <th>Mobile Number</th>
                                    <th>User Role</th>
                                    <th class="text-right">Actions</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th> <?php echo e($u->name); ?> </th>
                                        <th> <?php echo e($u->email); ?> </th>
                                        <th> <?php echo e($u->branch_id); ?> </th>
                                        <th> <?php echo e($u->mobile_number); ?> </th>
                                        <th>
                                            <?php $__currentLoopData = $u->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-pill badge-info"><?php echo e($r->name); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </th>
                                        <td class="td-actions text-right">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_users')): ?>
                                            <a href="/users/edit/<?php echo e($u->id); ?>" rel="tooltip"
                                                class="btn btn-success btn-round">
                                                <i class="material-icons">edit</i> <span class="mx-1">Edit</span>
                                            </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_users')): ?>
                                            <a href="/users/delete/<?php echo e($u->id); ?>" rel="tooltip"
                                                class="btn btn-danger btn-round">
                                                <i class="material-icons">close</i> <span class="mx-1">Delete</span>
                                            </a>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/users/index.blade.php ENDPATH**/ ?>