<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10 container">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-header card-header-rose card-header-text">
                    <div class="card-text">
                        <h4 class="card-title">Edit Permission</h4>
                    </div>
                </div>

            </div>
            <div class="card-body ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <form action="/permissions/update/<?php echo e($perm->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col">
                                        <div class="from-group">
                                            <label for="">Permission Name</label>
                                            <input type="text" name="permission_name" class="form-control" value="<?php echo e($perm->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="from-group">
                                            <label for=""> Name to View</label>
                                            <input type="text" name="view_name" class="form-control" value="<?php echo e($perm->view_name); ?>">
                                        </div>
                                    </div>
                                </div>


                                <table class="table">
                                    <tbody>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                <tr>
                                    <th> <?php echo e($r->name); ?> </th>
                                        <td class="td-actions text-right">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_permissions')): ?>
                                            <input type="checkbox" value=" <?php echo e($r->name); ?> " name="roles[]" id=""

                                            <?php $__currentLoopData = $roles_with_this_perm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rwtp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($r->name == $rwtp): ?>
                                                    checked
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            >
                                            <?php endif; ?>
                                        </td>
                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                    <tr >
                                        <button class="btn btn-danger" type="submit">Update Permission</button>
                                    </tr>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/permissions/edit.blade.php ENDPATH**/ ?>