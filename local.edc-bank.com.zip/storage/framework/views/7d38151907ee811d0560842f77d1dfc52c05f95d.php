<form action="<?php echo e('/form/data'); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    Book title:
    <br />
    <input type="text" name="title" />
    <br /><br />
    Logo:
    <br />
    <input type="file" name="logo" />
    <br /><br />
    <input type="submit" value=" Save " />
</form>
<?php /**PATH C:\xampp\htdocs\local.funimals.com\resources\views/form/form_view.blade.php ENDPATH**/ ?>