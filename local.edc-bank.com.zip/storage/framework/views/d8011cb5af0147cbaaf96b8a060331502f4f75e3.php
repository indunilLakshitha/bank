

<?php if($errors->any() ): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($success)): ?>
    <script>
        Swal.fire("<?php echo e($success); ?>")
    </script>
<?php endif; ?>

<?php if(isset($error)): ?>
    <script>
        Swal.fire("<?php echo e($error); ?>")
    </script>
<?php endif; ?>

<?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/layouts/messages.blade.php ENDPATH**/ ?>