<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="col-md-10 col-12 mr-auto ml-auto">
            <div class="card">
                <div class="card-body">
                    <form id="private_1" action="/member/add/status" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="customer_id" value=<?php echo e($cus_id); ?>>
                        <div class="tab-pane active" id="status">
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Birth Date / Nic Date</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <input type="date" name="date_of_birth" class="form-control col-3">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Religion</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <?php
                                            $rels = Illuminate\Support\Facades\DB::table('relegion_data')->get();
                                        ?>
                                        <select name="religion_data_id" id=""  class="selectpicker" id="married_status_id" data-style="select-with-transition">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $rels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->religion_data); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Married Status</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <?php
                                        $rels = Illuminate\Support\Facades\DB::table('married_statuses')->get();
                                    ?>
                                    <select name="married_status_id" id=""  class="selectpicker" id="married_status_id" data-style="select-with-transition">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $rels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->married_status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Gender</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <?php
                                        $rels = Illuminate\Support\Facades\DB::table('genders')->get();
                                    ?>
                                    <select name="gender_id" id=""  class="selectpicker" id="gender_id" data-style="select-with-transition">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $rels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->gender); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Race</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <?php
                                        $rels = Illuminate\Support\Facades\DB::table('races')->get();
                                    ?>
                                    <select name="race_id" id=""  class="selectpicker" id="race_id" data-style="select-with-transition">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $rels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->race); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Date Became Member</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <input type="date" name="member_date" class="form-control col-3">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Joined Date</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <input type="date" name="join_date" class="form-control col-3">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary">NEXT</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/members/2_statusanddated.blade.php ENDPATH**/ ?>