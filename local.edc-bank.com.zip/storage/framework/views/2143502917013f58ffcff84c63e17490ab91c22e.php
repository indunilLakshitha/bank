<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="container-fluid">
        
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/dashboard.blade.php ENDPATH**/ ?>