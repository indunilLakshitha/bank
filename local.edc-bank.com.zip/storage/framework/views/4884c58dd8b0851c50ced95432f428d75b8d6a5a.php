<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header card-header-rose card-header-text">
                    <div class="card-text">
                        <h4 class="card-title">Savings Account Opening</h4>
                    </div>
                </div>
            </div>
            <form method="post" action="/product_details" class="form-horizontal">
            <input type="hidden" name="account_id" value="<?php echo e($account_id); ?>">
                <?php echo csrf_field(); ?>
                <div class="card ">
                    <div class="card-body ">
                        <div class="card-header card-header-rose card-header-text">
                            <div class="card-text">
                                <h4 class="card-title">Product Details</h4>
                            </div>
                        </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Sub Product Type</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <?php
                                            $prod_types = Illuminate\Support\Facades\DB::table('product_types')->get();
                                        ?>
                                        <select
                                        oninput="set_min_max(this.value)"
                                        name="product_type_id"   class="form-control" data-style="select-with-transition">
                                            <option value="">Select </option>
                                            <?php if(isset($prod_types)): ?>
                                            <?php $__currentLoopData = $prod_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->product_type); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Interest Type</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <select name="interest_type_id"   class="selectpicker" data-style="select-with-transition"

                                        >
                                            <?php
                                                $interest_types = Illuminate\Support\Facades\DB::table('interest_types')->get();
                                            ?>
                                            <option value="">Select </option>
                                            <?php if(isset($interest_types)): ?>
                                            <?php $__currentLoopData = $interest_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->interest_type); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Interest Rate</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <input type="number" name="interest_rate" id="interest_rate"  class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Currency</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <select name="currency_id"   class="selectpicker" data-style="select-with-transition">
                                            <?php
                                                $currencies = Illuminate\Support\Facades\DB::table('currencies')->get();
                                            ?>
                                            <option value="">Select </option>
                                            <?php if(isset($currencies)): ?>
                                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->currency_name); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <label class="col-sm-2 col-form-label">Account Level</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <select name="account_level"   class="selectpicker" data-style="select-with-transition">
                                            <option value="">Select </option>
                                            <?php if(isset($acc_levels)): ?>
                                            <?php $__currentLoopData = $acc_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($idtype->id); ?>">
                                                <?php echo e($acc_level->identification_type); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Initial Deposit Allow Mode</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <select name="deposite_mode_id"   class="selectpicker" data-style="select-with-transition">
                                             <?php
                                                $diposits = Illuminate\Support\Facades\DB::table('deposite_modes')->get();
                                            ?>
                                            <option value="">Select </option>
                                            <?php if(isset($diposits)): ?>
                                            <?php $__currentLoopData = $diposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($diposit->id); ?>">
                                                <?php echo e($diposit->deposite_mode); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Interest Credit Dated</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <input type="date" name="interest_credit_date" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Minimum Balance to active the account</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-5">
                                    <div class="form-group">
                                        <input type="number" name="minimum_balance">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                        <div class="col-6 text-right">
                        <button type="submit" class="btn btn-primary">NEXT</button>
                        </div>
                </div>
            </div>

            </form>
        </div>
    </div>
</div>

<script>
    const prod_types = <?php echo json_encode($prod_types, JSON_HEX_TAG); ?>


function set_min_max(id){
    if(id === ''){return}
    console.log(prod_types, id);

    prod_types.forEach(i => {
        // console.log(i.id, id);
        if(i.id === parseInt(id)){
            interest_rate.value = i.default_interest
            interest_rate.max = i.max_interest
        }
    })
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/savings/3_product_details.blade.php ENDPATH**/ ?>