<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                
                <h4 class="card-title">Create Role

                </h4>

            </div>
            <div class="card-body ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <form action="/roles/store" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="from-group">
                                    <label for="">Role Name</label>
                                    <input type="text" name="role_name" class="form-control">
                                </div>
                                <table class="table">
                                    <tbody>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th> <?php echo e($p->view_name); ?> </th>
                                        <td class="td-actions text-right">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_roles')): ?>
                                            <input type="checkbox" value=" <?php echo e($p->name); ?> " name="permissions[]" id="">
                                            <?php endif; ?>
                                        </td>
                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                    <tr >
                                        <button class="btn btn-danger" type="submit">Create Role</button>
                                    </tr>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/roles/create.blade.php ENDPATH**/ ?>