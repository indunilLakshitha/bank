<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header card-header-rose card-header-text">
                    <div class="card-text">
                        <h4 class="card-title">Savings Account Opening</h4>
                    </div>
                </div>
            </div>

                <div class="card ">
                    <div class="card-body ">
                            <div class="card-header card-header-rose card-header-text">
                                <div class="card-text">
                                    <h4 class="card-title">Guardian Information</h4>
                                </div>
                            </div>
                            <?php if(isset($guardians)): ?>
                                <table class="table">
                                    <tr><td>Guardian ID</td></tr>
                                    <?php $__currentLoopData = $guardians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <th><?php echo e($item->guardian_id); ?></th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-6 text-right">
                    <form action="/documents" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_data_id" value=<?php echo e($prod_id); ?>>
                        <input type="hidden" name="account_id" value=<?php echo e($account_id); ?>>
                        <input type="hidden" name="customer_id" value=<?php echo e($customer_id); ?>>
                        <button type="submit" class="btn btn-primary">SUBMIT</button>
                    </form>
                </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/savings/6_guardian_information.blade.php ENDPATH**/ ?>