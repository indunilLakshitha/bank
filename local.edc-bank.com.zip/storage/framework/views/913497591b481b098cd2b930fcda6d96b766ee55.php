<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card ">
        <div class="card-header card-header-rose card-header-text">
            <div class="card-text">
                <h4 class="card-title">Member Types</h4>
            </div>
        </div>
        <div class="card-body ">
            <form method="get" action="/" class="form-horizontal">
                <div class="row">
                    <label class="col-sm-2 col-form-label">Code</label>
                    <div class="col-sm-10">
                        <div class="form-group">
                            <input type="text" class="form-control">
                            <span class="bmd-help">USe Member Code To Search</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label">Description</label>
                    <div class="col-sm-10">
                        <div class="form-group">
                            <input type="text" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label">Type</label>
                    <div class="col-lg-5 col-md-6 col-sm-3">
                        <select class="selectpicker" data-style="select-with-transition" multiple title="Type"
                            data-size="7">
                            <option disabled> type 1</option>
                            <option disabled> type 2</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <label class="col-sm-2 col-form-label">Status</label>
                    <div class="col-lg-5 col-md-6 col-sm-3">
                        <select class="selectpicker" data-style="select-with-transition" multiple title="Type"
                            data-size="7">
                            <option disabled> type 1</option>
                            <option disabled> type 2</option>
                        </select>
                    </div>
                </div>


            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                
                <h4 class="card-title">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_member_type')): ?>
                    <a href="/permissions/add" rel="tooltip" class="btn btn-sm btn-primary btn-round pull-right">
                        <i class="material-icons">add</i> <span class="mx-1">Add</span>
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modify_member_type')): ?>
                    <a href="/permissions/add" rel="tooltip" class="btn btn-sm btn-primary btn-round pull-right">
                        <i class="material-icons">update</i> <span class="mx-1">Modify</span>
                    </a>
                    <?php endif; ?>
                    <a href="/members" rel="tooltip" class="btn btn-sm btn-primary btn-round pull-right">
                        <i class="material-icons">close</i> <span class="mx-1">Exit</span>
                    </a>
                </h4>

            </div>
            <div class="card-body ">
                <div class="row">
                    <div class="col-md-12">
                        <div class="material-datatables">
                            <table id="datatables" class="table table-striped table-no-bordered table-hover"
                                cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <th>No </th>
                                    <th>CODE</th>
                                    <th>DESCRIPTION</th>
                                </thead>
                                <tbody>
                                    


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/members/type.blade.php ENDPATH**/ ?>