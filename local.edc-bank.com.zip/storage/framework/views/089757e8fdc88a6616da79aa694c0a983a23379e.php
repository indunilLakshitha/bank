<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="col-md-10 col-12 mr-auto ml-auto">
            <div class="card">
                <div class="card-body">
                    <form id="private_1" action="/member/add/special-and-assets" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="customer_id" value=<?php echo e($cus_id); ?>>
                        <div class="tab-pane" id="special">
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Special Information</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <textarea name="special_information" id="" cols="70" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Real Member</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <select name="is_real_member" id="" class="form-control">
                                            <option value="">1</option>
                                            <option value="">2</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h5 class="text-center">Assets</h5>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Item</label>
                                <div class="col-sm-10">
                                    <div class="form-group">
                                        <input type="text" name="item" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Value</label>
                                <div class="col-sm-3">
                                    <input type="text" name="value" class="form-control">
                                </div>
                                <div class="col-sm-3">
                                    <select name="" id="" class="form-control">
                                        <option value="">1</option>
                                        <option value="">2</option>
                                    </select>
                                </div>
                                <div class="col-sm-2">
                                    <button class="btn btn-sm btn-primary">SUBMIT & FINISH </button>
                                </div>
                                <div class="col-sm-2">
                                    <button class="btn btn-sm btn-primary">Remove</button>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\lahiru ayya\local.edc-bank.com\resources\views/members/6_special_and_assets.blade.php ENDPATH**/ ?>