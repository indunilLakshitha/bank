@extends('layouts.app')

@section('content')
<div class="content">
    <div class="container-fluid">
      <div class="container-fluid">
        <div>
        <img style="margin-top:200px;margin-left: 400px;box-shadow: 2px 2px 2px 2px;" src="{{asset('logo.png')}}" alt="">
        </div>
      </div>
    </div>
  </div>



@endsection
